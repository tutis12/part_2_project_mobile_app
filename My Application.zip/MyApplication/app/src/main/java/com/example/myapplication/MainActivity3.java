package com.example.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;

public class MainActivity3 extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_STORAGE = 1000;
    private Button button;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        button = (Button)findViewById(R.id.button3);
        textView = (TextView)findViewById(R.id.fileText);

        String path = getIntent().getExtras().getString("path");
        path = path.substring(path.indexOf(":")+1);
        Toast.makeText(getApplicationContext(), path,
                Toast.LENGTH_SHORT).show();
        String text=readText(path);
        Toast.makeText(getApplicationContext(), text,
                Toast.LENGTH_SHORT).show();
        textView.setText(readText(path));


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack();
            }
        });
    }
    private String readText(String input)
    {
        File file = new File(input);
        byte[] fileContent = new byte[0];
        try {
            fileContent = Files.readAllBytes(file.toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        StringBuilder text = new StringBuilder();
        for(byte i : fileContent)
        {
            int x = i;
            x += 128;
            int  a = x/26;
            int b = x%26;
            char A = (char) ('a' + a);
            char B = (char) ('b' + a);
            text.append(A);
            text.append(B);
        }
        return text.toString();
    }
    public void goBack()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}